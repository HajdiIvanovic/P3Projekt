<?php
require 'vendor/autoload.php';
require 'bootstrap.php';
use Ivanovic\OntologijaRedatelji;
use Ivanovic\Projekt;
use Composer\Autoload\ClassLoader;

Flight::route('/', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('https://oziz.ffos.hr/nastava20192020/hivanovic_19/hivanovic_19.rdf');
  $info = $foaf->dump();
  echo "<h2>Ontologija redatelja za izradu P3 zadatka:</h2> <br/><br/>" . $info;
});

Flight::route('GET /search', function(){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Ivanovic\OntologijaRedatelji');
  $zapisi = $repozitorij->findAll();
  echo $doctrineBootstrap->getJson($zapisi);
});


Flight::route('GET /baza', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('https://oziz.ffos.hr/nastava20192020/hivanovic_19/hivanovic_19.rdf');
  foreach ($foaf->resources() as $resource) {

    $name = $foaf->get($resource, 'foaf:name'); 

    if($name != ''){

      $i = 0;
      $types[] = [];
      $annotations = "";

    
      $subject = $foaf->get($resource, 'dc:subject'); 

      $title = $foaf->get($resource, 'dc:title'); 

      foreach ($resource->properties() as $key) {
          $annotations .= $key . ': ' . $foaf->get($resource, $key) . "\n"; 
      }

      $ontologijaRedatelji = new OntologijaRedatelji();
      $ontologijaRedatelji->setPodaci(Flight::request()->data);

      $ontologijaRedatelji->setRedatelj($name); 
      $ontologijaRedatelji->setNajpoznatijiRadovi($title);
      $ontologijaRedatelji->setOpisZanimanja($subject);
      $ontologijaRedatelji->setRdfOpis($annotations);

      $doctrineBootstrap = Flight::entityManager();
      $em = $doctrineBootstrap->getEntityManager();

      $em->persist($ontologijaRedatelji);
      $em->flush();

      
    }
  }

  echo "U bazu je uspješno unijeta ontologija redatelja."; //https://oziz.ffos.hr/nastava20192020/hivanovic_19/ontologija/search

});

Flight::route('GET /search/@name', function($name){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Ivanovic\OntologijaRedatelji');
  $zapisi = $repozitorij->createQueryBuilder('p')
                        ->where('p.redatelj LIKE :redatelj')
                        ->setParameter('redatelj', '%'.$name.'%')
                        ->getQuery()
                        ->getResult();  
  echo $doctrineBootstrap->getJson($zapisi);

});

$cl = new ClassLoader('Ivanovic', __DIR__, '/src');
$cl->register();
require_once 'bootstrap.php';
Flight::register('entityManager', 'DoctrineBootstrap');

Flight::start();


