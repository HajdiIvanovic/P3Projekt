create database hivanovic_19 default character set utf8;
use hivanovic_19;
create table ontologijaRedatelji(
    sifra int not null primary key auto_increment,
    redatelj varchar(255) not null,
    najpoznatijiRadovi varchar(100) not null,
    opisZanimanja varchar(500) not null,
    rdfOpis text not null
);
insert into ontologijaRedatelji (redatelj,najpoznatijiRadovi, opisZanimanja, rdfOpis) 
values ("ontologijaRedatelji", "ontologijaRedatelji", "ontologijaRedatelji", "ontologijaRedatelji" );
