<?php

namespace Ivanovic;

/**
 * @Entity @Table(name="ontologijaRedatelji")
 **/


class OntologijaRedatelji
{
    /** @id @Column(type="integer") @GeneratedValue **/
    protected $sifra;

    /**
    * @Column(type="string")
    */
    private $redatelj;

    /**
    * @Column(type="string")
    */
    private $najpoznatijiRadovi;

    /**
    * @Column(type="string")
    */
    private $opisZanimanja;

    /**
    * @Column(type="string")
    */
    private $rdfOpis;

    public function getSifra(){
      return $this->sifra;
    }
  
    public function setSifra($sifra){
      $this->sifra = $sifra;
    }
  
    public function getRedatelj(){
      return $this->redatelj;
    }
  
    public function setRedatelj($redatelj){
      $this->redatelj = $redatelj;
    }
  
    public function getNajpoznatijiRadovi(){
      return $this->najpoznatijiRadovi;
    }
  
    public function setNajpoznatijiRadovi($najpoznatijiRadovi){
      $this->najpoznatijiRadovi = $najpoznatijiRadovi;
    }
  
    public function getOpisZanimanja(){
      return $this->opisZanimanja;
    }
  
    public function setOpisZanimanja($opisZanimanja){
      $this->opisZanimanja = $opisZanimanja;
    }
  
    public function getRdfOpis(){
      return $this->rdfOpis;
    }
  
    public function setRdfOpis($rdfOpis){
      $this->rdfOpis = $rdfOpis;
    }

   
  public function setPodaci($podaci)
	{
		foreach($podaci as $kljuc => $vrijednost){
			$this->{$kljuc} = $vrijednost;
		}
	}

}



?>
